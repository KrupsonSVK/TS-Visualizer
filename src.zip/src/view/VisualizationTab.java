package view;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import model.Packet;
import model.Stream;

import java.util.*;


public class VisualizationTab {

    public Scene scene;
    public Tab tabVisual;

    VisualizationTab(Scene scene, Tab tabVisual){
        this.scene = scene;
        this.tabVisual = tabVisual;
    }


    public void drawPackets(Stream stream) {

        ArrayList<Packet> sourcePIDs = new ArrayList<Packet>(stream.getPackets().subList(0, 100));
        Map<Integer, Integer> copyPIDs = new HashMap<Integer, Integer>(stream.getPIDs());
        Map<Integer, Integer> controlPIDs = new LinkedHashMap<Integer, Integer>(sortHashMap(copyPIDs));
        List<Integer> unsorted = new ArrayList<Integer>();

        for (Map.Entry<Integer, Integer> entry : copyPIDs.entrySet()) {
            unsorted.add(entry.getKey());
        }
        Collections.sort(unsorted);

        Pane drawingPane = new Pane();
        drawingPane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        drawingPane.setStyle("-fx-background-color: white");

        ScrollPane legendPane = new ScrollPane();
        legendPane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        legendPane.setStyle("-fx-background-color: white");

        ScrollPane scrollPane = new ScrollPane(drawingPane);
        scrollPane.setPrefHeight(scene.getHeight() * 0.6);//60%

        double heigth = scene.getHeight() * 0.6 - 2;
        //Canvas canvas = new Canvas(sourcePIDs.size(), heigth > unsorted.size() ? heigth : unsorted.size());
        Canvas canvas = new Canvas(scene.getWidth() * 10, scene.getHeight());

        GraphicsContext gc = canvas.getGraphicsContext2D();
        drawingPane.getChildren().add(canvas);

        Integer y = 0, x = 0;
        for (Packet pid : sourcePIDs)
            drawPacket(gc, pid.getPID(), unsorted.indexOf(pid.getPID()), x++);

        tabVisual.setContent(new VBox(scrollPane));
    }


    private <K, V> HashMap<V, K> reverse(Map<K, V> map) {
        HashMap<V, K> rev = new HashMap<V, K>();
        for (Map.Entry<K, V> entry : map.entrySet())
            rev.put(entry.getValue(), entry.getKey());
        return rev;
    }


    private <K, V extends Comparable<? super V>> Map<K, V> sortHashMap(Map<K, V> map) {
        List<Map.Entry<K, V>> list = new LinkedList<>(map.entrySet());

        Collections.sort(list, Comparator.comparing(o -> (o.getValue())));

        Map<K, V> result = new LinkedHashMap<>();

        for (Map.Entry<K, V> entry : list)
            result.put(entry.getKey(), entry.getValue());
        return result;
    }


    private void drawPacket(GraphicsContext gc, Integer pid, Integer y, Integer x) {
        gc.setStroke(Color.DARKRED);
        gc.strokeRoundRect(x * 45, y * 60, 45, 60, 10, 10); //x,y,height, width, archeigth, arcwidh
        gc.setStroke(Color.DARKRED);
        gc.strokeText("PID(" + pid + ")", x * 45, y * 60 + 60 / 2);
    }
}
