package model.psi;


public class CАТs extends PSI {

    public CАТs(short tableID, byte SSI, int sectionLength) {
        super(tableID, SSI, sectionLength);
    }

    public CАТs() {
    }
}
