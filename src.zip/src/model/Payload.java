package model;


public class Payload {
}
